#!/usr/bin/env python3
"""Working-hours report rollup: per employee, per day, per hour, from Secure Access ZTNA events.

Primary signal  : ZTNA access events (get_activity_ztna). Each event is a user opening a
                  private application or a ZTNA-client connection, with a timestamp and the user.
Secondary signal: hourly request totals per identity (get_top_identities per window), used only
                  to show that a device was connected when no ZTNA event exists.

Only timestamps, identities and the allowed/blocked verdict are read. Destinations, application
names, URLs and process names are never written to the input files (see references/workforce-ztna.md).

Inputs
  ztna.jsonl     one line per collection window:
                 {"from": ms, "to": ms, "truncated": false,
                  "events": [[ts_ms, "user label", "device label", "allowed", 0], ...]}
                 the last field is 1 when the source process is a known background service
  windows.jsonl  optional, hourly traffic totals (same format as activity_rollup.py)
  people.csv     identity,person,department,location   (one row per identity label)
  leave.csv      person,from,to,type                    (dates YYYY-MM-DD, inclusive)

Usage
  python workforce_rollup.py ztna.jsonl --people people.csv [--leave leave.csv]
         [--traffic windows.jsonl] --from 2026-10-01 --to 2026-10-07 --tz Asia/Jerusalem
         [--workdays sun,mon,tue,wed,thu] [--business 08-18] [--partial 4]
         [--late 10:00] [--early 15:00] [--min-events 1] [--flag-days 2] [--thin 3]
         [--merge report.json]
"""
from __future__ import annotations

import argparse
import csv
import json
import statistics
from collections import defaultdict
from datetime import date, datetime, timedelta

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore

DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def read_jsonl(path):
    out = []
    with open(path, encoding="utf-8") as f:
        txt = f.read().strip()
    if not txt:
        return out
    if txt[0] == "[":
        return json.loads(txt)
    return [json.loads(l) for l in txt.splitlines() if l.strip()]


def hm(minutes):
    if minutes is None:
        return None
    minutes = int(round(minutes))
    return f"{(minutes // 60) % 24:02d}:{minutes % 60:02d}"


def parse_hm(s):
    h, m = (s.split(":") + ["0"])[:2]
    return int(h) * 60 + int(m)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ztna", nargs="+")
    ap.add_argument("--people", required=True)
    ap.add_argument("--leave")
    ap.add_argument("--traffic", nargs="*", default=[])
    ap.add_argument("--from", dest="dfrom", required=True)
    ap.add_argument("--to", dest="dto", required=True)
    ap.add_argument("--tz", default="Asia/Jerusalem")
    ap.add_argument("--workdays", default="sun,mon,tue,wed,thu")
    ap.add_argument("--business", default="08-18", help="business hours, start-end (end exclusive)")
    ap.add_argument("--partial", type=float, default=4, help="business active hours below this = partial day")
    ap.add_argument("--late", default="10:00", help="first activity after this = late start")
    ap.add_argument("--early", default="15:00", help="last activity before this = early end")
    ap.add_argument("--min-events", type=int, default=1, help="ZTNA events in an hour to count it active")
    ap.add_argument("--flag-days", type=int, default=2, help="a rule must hold on this many workdays to flag")
    ap.add_argument("--thin", type=float, default=3, help="fewer ZTNA-active hours per worked day than this = thin signal")
    ap.add_argument("--connected-min", type=float, default=5)
    ap.add_argument("--merge")
    a = ap.parse_args()

    tz = ZoneInfo(a.tz) if ZoneInfo else None
    workdays = {d.strip().lower()[:3] for d in a.workdays.split(",") if d.strip()}
    b0, b1 = (int(x) for x in a.business.split("-"))
    late_m, early_m = parse_hm(a.late), parse_hm(a.early)
    d0, d1 = date.fromisoformat(a.dfrom), date.fromisoformat(a.dto)
    dates = [d0 + timedelta(days=i) for i in range((d1 - d0).days + 1)]

    # ---- people and leave
    ident2p, pinfo = {}, {}
    with open(a.people, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            ident = (r.get("identity") or "").strip()
            person = (r.get("person") or ident).strip()
            if not ident:
                continue
            ident2p[ident.lower()] = person
            pinfo.setdefault(person, {"department": (r.get("department") or "").strip(), "identities": []})
            pinfo[person]["identities"].append(ident)
    leave = defaultdict(dict)
    if a.leave:
        with open(a.leave, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                p = (r.get("person") or "").strip()
                lf, lt = date.fromisoformat(r["from"].strip()), date.fromisoformat((r.get("to") or r["from"]).strip())
                while lf <= lt:
                    leave[p][lf] = (r.get("type") or "Leave").strip()
                    lf += timedelta(days=1)

    def person_of(*labels):
        for l in labels:
            if l and l.lower() in ident2p:
                return ident2p[l.lower()]
        return None

    # ---- ZTNA events -> per person, per (date, hour) counts
    ev = defaultdict(lambda: defaultdict(int))
    ev_total = ev_bg = ev_unmapped = 0
    windows = truncated = 0
    span_ms = [None, None]
    for path in a.ztna:
        for rec in read_jsonl(path):
            windows += 1
            truncated += 1 if rec.get("truncated") else 0
            span_ms[0] = min(x for x in (span_ms[0], rec.get("from")) if x is not None)
            span_ms[1] = max(x for x in (span_ms[1], rec.get("to")) if x is not None)
            for e in rec.get("events") or []:
                ts, user, dev = e[0], e[1] if len(e) > 1 else "", e[2] if len(e) > 2 else ""
                bg = len(e) > 4 and bool(e[4])
                ev_total += 1
                if bg:
                    ev_bg += 1
                    continue
                p = person_of(user, dev)
                if not p:
                    ev_unmapped += 1
                    continue
                t = datetime.fromtimestamp(int(ts) / 1000, tz)
                ev[p][(t.date(), t.hour)] += 1

    # ---- traffic (optional) -> connected hours per person
    conn = defaultdict(set)
    tw = 0
    for path in a.traffic:
        for rec in read_jsonl(path):
            tw += 1
            start = datetime.fromtimestamp(int(rec["from"]) / 1000, tz)
            hours = max(1, round((int(rec["to"]) - int(rec["from"])) / 3_600_000))
            per = defaultdict(float)
            for row in rec.get("rows") or []:
                p = person_of(str(row[0]))
                if p:
                    per[p] += float(row[2] or 0)
            for p, req in per.items():
                if req / hours >= a.connected_min:
                    for h in range(hours):
                        t = start + timedelta(hours=h)
                        conn[p].add((t.date(), t.hour))

    # ---- per person
    people_out = []
    for person in sorted(pinfo, key=lambda p: (pinfo[p]["department"].lower(), p.lower())):
        days = []
        for d in dates:
            wd = DAY_NAMES[d.weekday()] in workdays
            lv = leave.get(person, {}).get(d) or leave.get("*", {}).get(d)   # "*" = public holiday for everyone
            states, counts = [], []
            for h in range(24):
                n = ev[person].get((d, h), 0)
                counts.append(n)
                if n >= a.min_events:
                    states.append("ztna")
                elif (d, h) in conn[person]:
                    states.append("conn")
                else:
                    states.append("none")
            act = [h for h in range(24) if states[h] == "ztna"]
            biz = [h for h in act if b0 <= h < b1]
            aft = [h for h in act if not (b0 <= h < b1)] if wd else act
            biz_conn = [h for h in range(b0, b1) if states[h] != "none"]
            first = min(biz) * 60 if biz else None
            last = (max(biz) + 1) * 60 if biz else None
            gap = 0
            if biz:
                run = 0
                for h in range(min(biz), max(biz) + 1):
                    run = run + 1 if states[h] != "ztna" else 0
                    gap = max(gap, run)
            if not wd:
                status = "offday_active" if act else "offday"
            elif lv:
                status = "leave"
            elif len(biz) >= a.partial:
                status = "worked"
            elif biz:
                status = "partial"
            elif biz_conn:
                status = "connected_only"
            else:
                status = "no_activity"
            days.append({
                "date": d.isoformat(), "label": d.strftime("%a %-d %b"), "workday": wd, "leave": lv,
                "states": states, "events": counts, "status": status,
                "first": hm(first), "last": hm(last), "biz_active_h": len(biz), "after_active_h": len(aft),
                "biz_connected_h": len(biz_conn), "longest_gap_h": gap, "events_total": sum(counts),
            })

        wdays = [x for x in days if x["workday"] and not x["leave"]]
        worked = [x for x in wdays if x["status"] in ("worked", "partial")]
        avg_act = round(statistics.mean([x["biz_active_h"] for x in worked]), 1) if worked else 0

        def avg_t(key):
            v = [parse_hm(x[key]) for x in worked if x[key]]
            return hm(statistics.mean(v)) if v else None

        metrics = {
            "workdays": len([x for x in days if x["workday"]]),
            "leave_days": len([x for x in days if x["workday"] and x["leave"]]),
            "worked": len([x for x in wdays if x["status"] == "worked"]),
            "partial": len([x for x in wdays if x["status"] == "partial"]),
            "connected_only": len([x for x in wdays if x["status"] == "connected_only"]),
            "no_activity": len([x for x in wdays if x["status"] == "no_activity"]),
            "avg_biz_active_h": avg_act,
            "avg_first": avg_t("first"), "avg_last": avg_t("last"),
            "after_active_h": sum(x["after_active_h"] for x in days),
            "biz_active_h": sum(x["biz_active_h"] for x in wdays),
            "events": sum(x["events_total"] for x in days),
        }
        act_days = [x for x in days if x["biz_active_h"] + x["after_active_h"] > 0]
        avg_all = statistics.mean([x["biz_active_h"] + x["after_active_h"] for x in act_days]) if act_days else 0
        if act_days and avg_all >= a.thin:
            signal = "ztna"          # enough application access to read working hours from it
        elif act_days:
            signal = "thin"          # some access, too little to judge hours: read with care
        elif any(x["biz_connected_h"] for x in wdays):
            signal = "traffic"       # only device connectivity is visible
        else:
            signal = "none"
        # review flags (rules, never a score)
        flags = []

        # Rules that read application activity only apply when this person's ZTNA signal is usable;
        # otherwise the absence of events says nothing about work and would produce false flags.
        ztna_ok = signal == "ztna"

        def add(rule, title, ds, detail, needs_ztna=True):
            if needs_ztna and not ztna_ok:
                return
            if len(ds) >= a.flag_days:
                flags.append({"rule": rule, "title": title, "dates": ds, "detail": detail})

        add("R1", "No activity on workdays", [x["date"] for x in wdays if x["status"] == "no_activity"],
            "No ZTNA activity and no connected device during business hours, with no leave recorded.", needs_ztna=False)
        add("R2", "Connected but no ZTNA activity", [x["date"] for x in wdays if x["status"] == "connected_only"],
            "A device was online during business hours but no application access was recorded.")
        add("R3", f"Under {a.partial:g} active business hours", [x["date"] for x in wdays if x["status"] == "partial"],
            f"Fewer than {a.partial:g} business hours with application access.")
        add("R4", f"Start after {a.late} or end before {a.early}",
            [x["date"] for x in worked if (x["first"] and parse_hm(x["first"]) > late_m) or (x["last"] and parse_hm(x["last"]) < early_m)],
            "First or last application access of the business day outside the expected range.")
        tot_biz, tot_aft = metrics["biz_active_h"], metrics["after_active_h"]
        if ztna_ok and tot_aft > tot_biz and tot_aft >= 3:
            flags.append({"rule": "R5", "title": "Most activity after hours",
                          "dates": [x["date"] for x in days if x["after_active_h"]],
                          "detail": f"{tot_aft} active hours after hours vs {tot_biz} in business hours."})
        people_out.append({"name": person, "department": pinfo[person]["department"],
                           "identities": pinfo[person]["identities"], "signal": signal,
                           "days": days, "metrics": metrics, "flags": flags})

    n = len(people_out)
    measurable = [p for p in people_out if p["signal"] == "ztna"]
    summary = {
        "people": n,
        "workdays": len([d for d in dates if DAY_NAMES[d.weekday()] in workdays]),
        "avg_biz_active_h": round(statistics.mean([p["metrics"]["avg_biz_active_h"] for p in measurable]), 1) if measurable else None,
        "no_activity_days": sum(p["metrics"]["no_activity"] for p in people_out),
        "after_active_h": sum(p["metrics"]["after_active_h"] for p in people_out),
        "flagged": sum(1 for p in people_out if p["flags"]),
        "signal_ztna": len(measurable),
        "signal_thin": sum(1 for p in people_out if p["signal"] == "thin"),
        "signal_traffic": sum(1 for p in people_out if p["signal"] in ("traffic", "none")),
        "ztna_coverage_pct": round(100 * len(measurable) / n, 1) if n else 0,
        "events": ev_total, "events_background": ev_bg, "events_unmapped": ev_unmapped,
        "ztna_windows": windows, "ztna_truncated": truncated, "traffic_windows": tw,
    }
    block = {
        "period": {"from": a.dfrom, "to": a.dto, "tz": a.tz, "dates": [d.isoformat() for d in dates],
                   "workdays": sorted(workdays, key=DAY_NAMES.index), "business": [b0, b1]},
        "settings": {"min_events": a.min_events, "partial_hours": a.partial, "late": a.late, "early": a.early,
                     "flag_days": a.flag_days, "thin": a.thin, "connected_min": a.connected_min},
        "summary": summary, "people": people_out,
    }
    if a.merge:
        with open(a.merge, encoding="utf-8") as f:
            rep = json.load(f)
        rep["workforce"] = block
        with open(a.merge, "w", encoding="utf-8") as f:
            json.dump(rep, f, ensure_ascii=False, indent=1)
        print(f"Merged {n} people, {len(dates)} days, {ev_total} ZTNA events ({ev_bg} background, {ev_unmapped} unmapped) into {a.merge}")
        for p in people_out:
            m = p["metrics"]
            print(f"  {p['name']:<28} signal={p['signal']:<7} worked={m['worked']} partial={m['partial']} "
                  f"connected_only={m['connected_only']} no_activity={m['no_activity']} leave={m['leave_days']} "
                  f"avg_biz_h={m['avg_biz_active_h']} after_h={m['after_active_h']} flags={[f['rule'] for f in p['flags']]}")
    else:
        print(json.dumps(block, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
