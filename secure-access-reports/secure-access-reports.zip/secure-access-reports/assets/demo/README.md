Fictional demo inputs for the Working Hours Report (Contoso Ltd., 20 Sep – 3 Oct 2026).
Try the pipeline without a tenant:

    cp assets/example_workforce_report.json report.json
    python scripts/workforce_rollup.py assets/demo/ztna.jsonl --people assets/demo/people.csv \
        --leave assets/demo/leave.csv --traffic assets/demo/windows.jsonl \
        --from 2026-09-20 --to 2026-10-03 --merge report.json
    python scripts/render_report.py report.json --out out --pdf

The --merge step replaces the "workforce" block in report.json.
