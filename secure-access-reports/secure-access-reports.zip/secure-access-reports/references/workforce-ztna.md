# Working-hours report (ZTNA access events)

Per employee: which business hours (default 08:00–18:00, Sun–Thu) and which after-hours had application activity, exact first and last activity per day, absence and partial days, and a rule-based review list for managers. This is the preferred workforce report when employees reach company applications through Secure Access Zero Trust (ZTNA). The older traffic-volume method (`workforce-activity.md`) remains the fallback.

Customer prompt library: `references/prompts.md`.

## Signal used
- **Primary – ZTNA access events** (`get_activity_ztna`): every access to a private application (ERP, file shares, RDP, intranet) through the ZTNA client or browser-based ZTNA, with timestamp, user and allowed/blocked verdict. These events happen when a person works with a company application, so they mark working time far better than traffic volume.
- **Secondary – hourly traffic totals** (`get_top_identities` per window): only to show that the laptop was online in hours without any access event ("Connected, no app activity").

What ZTNA does not record (verified on a live tenant, Oct 2026): ordinary internet traffic through the ZTNA client is not logged as events; only private-application access and blocked requests are. Employees who never use private applications through ZTNA produce no events, so the report cannot measure their working hours. The pre-flight check below detects this before any long collection.

## Before collecting
1. **Disclosure.** Ask once per tenant whether employees were informed that access to company systems is monitored (policy or contract). If not confirmed, produce the department-level version only (prompt P5): map people to department names in `people.csv`.
2. **Files from the customer** (templates in `assets/`):
   - `people.csv` – `identity,person,department,location`. One row per identity label exactly as Secure Access shows it: the directory user (e.g. `Dana Levi (dana@contoso.com)` or the plain UPN, whichever the tenant shows), the ZTNA client device name, the roaming-client device name.
   - `leave.csv` – `person,from,to,type` (approved vacation, sick leave, public holidays as `*`). Days in it are excluded from every rule.
3. **Settings** (defaults in brackets): period [last 14 days, max 31], time zone [Asia/Jerusalem], workweek [sun,mon,tue,wed,thu], business hours [08-18], partial-day threshold [4 active hours], late start [10:00], early end [15:00], rule minimum [2 workdays].

## Pre-flight check (always)
Call `get_activity_ztna(from_time=<period start ms>, to_time=<end ms>, limit=1000)` once. Count events per mapped person per workday (drop background events, see below).
- ≥ 3 events per person per workday on average → proceed.
- Fewer → tell the user plainly how many events exist and that working hours cannot be measured from ZTNA for those people; offer the traffic-based report (`workforce-activity.md`) or adding identity-provider sign-in logs (Duo / Entra). Do not build a report that implies absence from missing events.

## Collect ZTNA events
Events carry their own timestamps, so window size does not affect accuracy; it only has to keep each call under the limit.
1. `python scripts/day_windows.py --days <N> --tz <zone>` → one window per day.
2. For each window: `get_activity_ztna(from_time, to_time, limit=1000)`. If the call returns 1000 events, split the window in two and query each half; repeat until no window returns the limit. Run at most 4 calls in parallel (the local server times out under larger bursts).
3. Write one JSON line per window to `ztna.jsonl`, keeping **only** these fields of each event:
   ```json
   {"from": 1790802000000, "to": 1790888400000, "truncated": false,
    "events": [[1790963226000, "Dana Levi (dana@contoso.com)", "LT-DLEVI", "allowed", 0]]}
   ```
   `[timestamp, directory-user label, ZTNA-client label, verdict, background]`. User label = the identity with type `directory_user` / `saml_user` (empty if none); device label = type `ztna_client`.
   `background` = 1 when `sourceprocess.name` matches a background service: `onedrive`, `sync`, `update`, `defender`, `msmpeng`, `svchost`, `searchapp`, `searchindexer`, `backgroundtask`, `officeclicktorun`, `edgeupdate`, `googleupdate`, `teams_updater`. Browser-based events have no process → 0.
4. **Never write** `requestedipfqdn`, application or application-group names, `sourceprocess` names or hashes, device IP, transaction IDs or posture data to any file, report or reply. The process name is read only to set the background bit and then discarded.

## Collect connectivity (recommended)
`python scripts/day_windows.py --days <N> --tz <zone> --bucket hours --size 2 --compact`, then `get_top_identities(from, to, limit=200)` per window → `windows.jsonl` in the compact `rows` form described in `workforce-activity.md`. Skip it only if the user wants a faster run; then "Connected, no app activity" and rule R2 are not available.

## Roll up and render
```bash
python scripts/workforce_rollup.py ztna.jsonl --people people.csv --leave leave.csv \
       --traffic windows.jsonl --from 2026-09-20 --to 2026-10-03 --tz Asia/Jerusalem \
       --business 08-18 --partial 4 --late 10:00 --early 15:00 --flag-days 2 --merge report.json
python scripts/render_report.py report.json --out <dir> --pdf
```
`report.json` needs `report` (title "Working Hours Report", customer, period_label, classification "Confidential – HR and management only"), `posture.headline` (no `level`), `summary`, `insights` (keys `wf_overview`, `wf_flags`, `wf_matrix`, `wf_absence`, `wf_person`, `method`), `methodology`, and optionally `labels: {"method": "How This Was Checked"}`. Example: `assets/example_workforce_report.json`; demo inputs: `assets/demo/`.

Sections rendered: Working Hours Overview → Manager Review List → Workdays by Employee (day matrix) → Absence and Partial Days → Hour-by-Hour Detail by Employee (24-hour grid per day, business hours shaded, exact first/last/gaps) → How to Read This Report (fixed) → Recommendations → How This Was Checked.

## Definitions (the rollup applies these; quote them in "How This Was Checked")
| Term | Rule |
|---|---|
| Active hour | ≥ 1 non-background ZTNA event by the employee in that clock hour (`--min-events`). |
| Business / after hours | 08:00–18:00 on workdays / everything else, including weekends. |
| Worked day | ≥ 4 active business hours. **Partial day**: 1–3. **Connected, no app activity**: laptop online in business hours, no events. **No activity**: neither, no leave. **Approved leave**: in `leave.csv`. |
| First / last | Start of the first and end of the last active business hour. |
| Longest gap | Longest run of business hours without events between first and last. |
| Signal | `ztna`: ≥ 3 active hours per active day → hours are measurable. `thin`: some events, too few. `traffic`: device connectivity only. |

## Review rules (flags, never scores)
| Rule | Fires when, on ≥ `--flag-days` workdays (leave excluded) | Needs ZTNA signal |
|---|---|---|
| R1 | No activity and no connected device in business hours | No |
| R2 | Laptop connected, no application access | Yes |
| R3 | Partial day (under 4 active business hours) | Yes |
| R4 | First activity after 10:00 or last before 15:00 | Yes |
| R5 | More active hours after hours than in business hours (≥ 3) | Yes |

R2–R5 are skipped for people whose signal is not `ztna`: missing events then say nothing about work. The overview shows a warning with the count of people this affects.

## Writing rules
- Present flags as patterns for the manager to discuss with the employee: "worth a conversation", never "lazy", "underperforming", "slacking", no scores, no "bottom N" or ranked lists. Order is department, then name.
- State facts with times: "Partial days on 22, 24 and 29 Sep: 3 active business hours, 10:00–15:00", not "works half days".
- In the summary, name people only together with the rule and dates that put them there.
- The fixed "How to Read This Report" section always renders; keep its statement that the figures alone are not a basis for disciplinary decisions.
- Classification on the cover: HR and management only. No destinations, applications or sites appear anywhere.
