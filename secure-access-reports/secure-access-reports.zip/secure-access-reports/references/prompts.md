# Prompt library – Working Hours Report (Secure Access ZTNA)

Copy a prompt, replace the `<…>` values, attach `people.csv` and `leave.csv` (templates: `assets/people_template.csv`, `assets/leave_template.csv`). Every prompt starts with the same settings block so results are comparable from week to week.

## Settings block (paste at the top of every prompt)
```
Tenant: <Company name>. Time zone: Asia/Jerusalem. Workweek: Sunday–Thursday.
Business hours: 08:00–18:00. After hours: everything else, including Friday–Saturday.
Employees are informed that access to company systems is monitored (policy <name/date>).
Identity-to-employee mapping: people.csv (attached). Approved leave and holidays: leave.csv (attached).
Distribution: HR and management only.
```

## P0 – Readiness check (run once per customer, before anything else)
```
/secure-access-reports <settings block>
Run the ZTNA pre-flight check for the last 14 days only – do not build a report yet.
Tell me: how many ZTNA access events exist, how many employees in people.csv have events,
the average events per employee per workday, and which employees have none.
Also list identities that appear in Secure Access but are missing from people.csv.
Recommend whether the Working Hours Report can be measured from ZTNA for this tenant.
```

## P1 – Weekly working-hours report (per employee)
```
/secure-access-reports <settings block>
Create a Working Hours Report for <Sun DD Mon> to <Thu DD Mon>, using ZTNA access events
as the activity signal and hourly connectivity as the secondary signal.
For every employee show:
- each workday: first and last activity, active business hours, longest gap, after-hours active hours, day status
- an hour-by-hour grid (24 columns, business hours shaded) with the number of access events per hour
- weekend activity, if any
Include the Workdays by Employee matrix, the Absence and Partial Days table and the Manager Review List.
Order by department, then name. Explain every threshold in "How This Was Checked".
Deliver PDF and HTML.
```

## P2 – Absence and out-of-office report
```
/secure-access-reports <settings block>
For <period>, list every workday on which an employee had no activity, was connected without
application activity, or had a partial day (under 4 active business hours). Exclude leave.csv days.
For each: date, status, connected business hours, active business hours, and any activity after hours
that day (e.g. worked 19:00–23:00 instead). Add a per-employee count: days not fully worked out of workdays.
```

## P3 – Manager review list (exceptions only)
```
/secure-access-reports <settings block>
Create the Manager Review List for the last 30 days. Apply rules R1–R5 with these thresholds:
partial day under 4 active business hours, late start after 10:00, early end before 15:00,
a rule must hold on at least 3 workdays. Exclude leave.csv days.
For each flagged employee: the rule, the dates, the hour-by-hour evidence for those dates,
and one factual sentence. Do not rank employees or label them. List employees with no flags as a count.
```

## P4 – Single employee, for a 1:1 conversation
```
/secure-access-reports <settings block>
Create a Working Hours Report for <employee name> only, <period>.
Show every workday with first/last activity, active business hours, gaps and after-hours activity,
and the hour-by-hour grid.
Keep it factual; add the "How to Read This Report" limits so it can be shared with the employee.
```

## P5 – Department view (no names – leadership, or when disclosure is not confirmed)
```
/secure-access-reports <settings block, without the disclosure line>
Create a department-level Working Hours Report for <period>: map people.csv rows to department names
so no individual appears. Per department: average active business hours per day, share of activity
after hours, typical start and end, and workdays with no activity (as a count).
```

## P6 – Hebrew version
Add to any prompt:
```
Write the report in Hebrew (RTL); keep product names in English (Secure Access, ZTNA).
```

## P7 – Run automatically every week
```
Set up a scheduled task every Sunday at 08:45 Israel time that runs prompt P1 for the previous
Sunday–Thursday week (and P3 for the last 30 days) with the attached people.csv and leave.csv,
and sends me both PDFs.
```

## Tuning switches (add a line to any prompt)
| Want | Add |
|---|---|
| Different hours | `Business hours: 09:00–17:00.` |
| Stricter day | `Partial day: under 6 active business hours.` |
| Ignore light activity | `Count an hour as active only with 3 or more access events.` |
| Faster run | `Skip connectivity collection; ZTNA events only.` (R2 not available) |
| Longer look-back | `Period: last 31 days.` (maximum per report) |

## What the report will not do
- Name applications, sites or files an employee used.
- Score or rank employees.
- Treat a missing event as proof of no work: meetings, phone calls and offline work are invisible, and rules R2–R5 are switched off for anyone whose ZTNA activity is too low to measure.
